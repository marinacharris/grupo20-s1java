import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.awt.Dimension;

public class App extends JFrame{
    public App(){
        String[] nombreColumnas = {"Nombre", "Edad", "Extranjero"};
        Object[][] datos = {
            {"Ana", 20, false},
            {"Philip", 35, true},
            {"Carlos", 27, false},
        };

        //crear el modelo
        DefaultTableModel modelo = new DefaultTableModel(datos, nombreColumnas);
           
        //Añadir columna
        String[] datosColumna = {"Contadora", "Ingeniero", "Administrador"};
        modelo.addColumn("Profesión", datosColumna);

        //Añadir Fila
        Object[] datosFila = {"Laura", 25, false, "Enfermera"};
        modelo.addRow(datosFila);
        modelo.addRow(datosFila);
        modelo.addRow(datosFila);
        modelo.addRow(datosFila);
        modelo.addRow(datosFila);
        
 
        JTable tabla = new JTable(modelo);
        tabla.setPreferredScrollableViewportSize(new Dimension(250,100));
        add(tabla);
        JScrollPane scrollPane = new JScrollPane(tabla);
        add(scrollPane);
        
    }

    public static void main(String[] args) throws Exception {
       App ventana = new App();
       ventana.pack();
       ventana.setVisible(true);
       ventana.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}
