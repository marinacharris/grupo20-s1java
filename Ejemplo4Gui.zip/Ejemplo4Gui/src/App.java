import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class App extends JFrame implements ActionListener{
    private JTextField txtUsuario;
    private JPasswordField txtClave;
    private JLabel lblClave;
    private JLabel lblUsuario;
    private JButton btnLogin;

    public App(){
        setLayout(null);
        lblUsuario = new JLabel("Usuario");
        lblUsuario.setBounds(20,10,100,30);
        add(lblUsuario);
        lblClave = new JLabel("Clave");
        lblClave.setBounds(20,40,100,30);
        add(lblClave);
        txtUsuario = new JTextField();
        txtUsuario.setBounds(120,10, 100,20);
        add(txtUsuario);
        txtClave = new JPasswordField();
        txtClave.setBounds(120,40,100,20);
        add(txtClave);
        btnLogin = new JButton("Login");
        btnLogin.setBounds(20,80,100,20);
        add(btnLogin);
        btnLogin.addActionListener(this);
    }

    public static void main(String[] args) throws Exception {
        App login = new App();
        login.setBounds(20,20,280,160);
        login.setVisible(true);
        login.setTitle("Loginv
        login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnLogin){
            String clave = new String(txtClave.getPassword());
            if(Login.autenticar(txtUsuario.getText(),clave)){
                JOptionPane.showMessageDialog(App.this,"Ingreso exitoso","Login",JOptionPane.INFORMATION_MESSAGE);

            }else{
                JOptionPane.showMessageDialog(App.this,"Usuario o clave incorrecta", "Login",JOptionPane.ERROR_MESSAGE);
            }
        }
        
    }
}
