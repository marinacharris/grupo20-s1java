import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Gui extends JFrame implements ActionListener{
    private JLabel lblSaludo, lblVersion;
    private JButton btnSalir,btnTitulo;
    private JTextField txtTitulo;

    public Gui() {
        setLayout(null); //Utilizamos posiciones absolutas de los componentes
        lblSaludo = new JLabel("Hola Mundo");
        lblSaludo.setFont(new Font("Helvetica",Font.BOLD,20));
        lblSaludo.setBounds(20,20,150,20);
        add(lblSaludo); //add y setLayout son métodos heredados de la clase JFrame
        lblVersion = new JLabel("Version 1.0");
        lblVersion.setBounds(20, 50, 100, 20);
        add(lblVersion); //add y setLayout son métodos heredados
        btnSalir = new JButton("Salir");
        btnSalir.setBounds(240, 200,100,30);
        add(btnSalir); //add y setLayout son métodos heredados
        btnSalir.addActionListener(this);
        txtTitulo = new JTextField();
        txtTitulo.setBounds(20, 100, 150, 20);
        add(txtTitulo);
        btnTitulo = new JButton("Cambiar");
        btnTitulo.setBounds(240,160,100,30);
        add(btnTitulo);
        btnTitulo.addActionListener(this);
    }


    public static void main(String[] args) throws Exception {
        Gui ventana1 = new Gui();
        ventana1.setBounds(50,50,400,300);
        ventana1.setVisible(true);
        ventana1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana1.setTitle("Hola mundo");

    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnSalir){
            System.exit(0);
        }
        if (e.getSource() == btnTitulo){
            setTitle(txtTitulo.getText());
        }
                
    }
}
