package book;

public class App 
{
    public static void main( String[] args )
    {
        new BookShop().start();
    }
}
