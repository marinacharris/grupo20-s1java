import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class App extends JFrame implements ActionListener, ChangeListener{
    private JTextField txtNum1, txtNum2;
    private JButton btnCalcular;
    private JLabel lblResultado;
    private JRadioButton rbtnSuma, rbtnResta, rbtnMul, rbtnDiv;
    private ButtonGroup btnGrupo;



    public App(){
        setLayout(null);
        txtNum1 = new JTextField();
        txtNum1.setBounds(10,10,100,30);
        add(txtNum1);
        txtNum2 = new JTextField();
        txtNum2.setBounds(10,50,100,30);
        add(txtNum2);
        btnCalcular = new JButton("Calcular");  
        btnCalcular.setBounds(10,90,100,30);
        add(btnCalcular);
        lblResultado = new JLabel("--");
        lblResultado.setBounds(190,60,80,30);
        lblResultado.setFont(new Font("Arial", Font.BOLD, 15));
        add(lblResultado);
        btnCalcular.addActionListener(this);
        btnGrupo = new ButtonGroup();
        rbtnSuma = new JRadioButton("+");
        rbtnSuma.setBounds(130,30, 50,20);
        add(rbtnSuma);
        btnGrupo.add(rbtnSuma);
        rbtnSuma.addChangeListener(this);
        rbtnResta = new JRadioButton("-");
        rbtnResta.setBounds(130,50,50,20);
        add(rbtnResta);
        btnGrupo.add(rbtnResta);
        rbtnResta.addChangeListener(this);
        rbtnMul = new JRadioButton("*");
        rbtnMul.setBounds(130,70,50,20);
        add(rbtnMul);
        btnGrupo.add(rbtnMul);
        rbtnMul.addChangeListener(this);
        rbtnDiv = new JRadioButton("/");
        rbtnDiv.setBounds(130,90,50,20);
        add(rbtnDiv);
        btnGrupo.add(rbtnDiv);
        rbtnDiv.addChangeListener(this);

    }
    public static void main(String[] args) throws Exception {
        App ventana = new App();
        ventana.setBounds(100,100, 250,180);
        ventana.setVisible(true);
        ventana.setTitle("Mini calc");
        ventana.setResizable(false);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()== btnCalcular){
            Double x = Double.parseDouble(txtNum1.getText());
            Double y = Double.parseDouble(txtNum2.getText());
            Double resultado = 0.0;
            if(rbtnSuma.isSelected()){
                resultado = x+y;
            }
            if(rbtnResta.isSelected()){
                resultado = x-y;
            }
            if(rbtnMul.isSelected()){
                resultado = x*y;
            }
            if(rbtnDiv.isSelected()){
                resultado = x/y;
            }
            lblResultado.setText(String.valueOf(resultado));
        }
        
    }
    @Override
    public void stateChanged(ChangeEvent e) {
       
    }
}
