package sqjava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class App 
{
    public static void main( String[] args )
    {
        String jdcbUrl = "jdbc:sqlite:C:\\Users\\robot\\Desktop\\hr.db";
        try{
            //select
            Connection conexion = DriverManager.getConnection(jdcbUrl); //conectando JDBC a SQLITE
            String sql = "select * from employees e where salary > 10000";
            Statement stm = conexion.createStatement();
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()){
                Integer id = rs.getInt("employee_id");
                String nombre = rs.getString("first_name");
                String apellido = rs.getString("last_name");
                Double salario = rs.getDouble("salary");
                System.out.println(id + "\t"+nombre+"\t"+apellido + "\t"+salario);
            }
            rs.close();
            stm.close();
            conexion.close();
        }
        catch (Exception e){
            System.out.println("Error al acceder a la base de datos");
            System.out.println(e.getMessage());
        }
        // Insert into
        try{
            Connection conexion = DriverManager.getConnection(jdcbUrl);
            String sqli = "insert into departments (department_name, location_id) values ('Mantenimiento',1500)";
            Statement stm = conexion.createStatement();
            int rows = stm.executeUpdate(sqli);
            if(rows >0){
                System.out.println("Registro creado con exito");
            }
            stm.close();
            conexion.close();
        }
        catch(Exception e){
            System.out.println("Error al crear el registro");
            System.out.println(e.getMessage());
        }

        // update
        try{
            Connection conexion = DriverManager.getConnection(jdcbUrl);
            String sqlu = "update departments set department_name = 'I+D' where department_id = 12";
            Statement stm = conexion.createStatement();
            int rows = stm.executeUpdate(sqlu);
            if (rows >0){
                System.out.println("registro actualizado");
            }
            stm.close();
            conexion.close();
        }
        catch (Exception e){
              System.out.println("No se pudo actualizar el registro");  
              System.out.println(e.getMessage());
        }
        //delete
        try{
            Connection conexion = DriverManager.getConnection(jdcbUrl);
            String sqld = "delete from regions where region_id = 5";
            Statement stm = conexion.createStatement();
            int rows = stm.executeUpdate(sqld);
            if (rows>0){
                System.out.println("Registro borrado");
            }
            stm.close();
            conexion.close();
        }
        catch(Exception e){
            System.out.println("No se pudo borar el registro");
            System.out.println(e.getMessage());

        }
    }
}
